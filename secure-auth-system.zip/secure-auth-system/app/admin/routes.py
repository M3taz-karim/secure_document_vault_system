from flask import Blueprint, jsonify, render_template, request

from app.extensions import db
from app.models.user import User
from app.models.document import Document
from app.utils import token_required, role_required
from . import admin_bp
import os



# ── UI Pages ──────────────────────────────────────────────────────
@admin_bp.route("/ui/dashboard")
def dashboard_page():
    return render_template("dashboard.html")


@admin_bp.route("/ui/admin")
def admin_page():
    return render_template("admin.html")


# ── Protected API stubs (used by dashboard API tester) ───────────
@admin_bp.route("/admin")
@token_required
@role_required("Admin")
def admin_api(user):
    return jsonify({
        "message": "Welcome Admin",
        "role":    user["role"],
        "access":  ["user_management", "roles", "audit_log", "system_settings"],
    })


@admin_bp.route("/manager")
@token_required
@role_required("Admin", "Manager")
def manager_api(user):
    return jsonify({
        "message": "Welcome Manager",
        "role":    user["role"],
        "access":  ["reports", "team_management", "document_review"],
    })


@admin_bp.route("/profile")
@token_required
@role_required("Admin", "Manager", "User")
def profile_api(user):
    return jsonify({
        "message": "Welcome",
        "role":    user["role"],
        "access":  ["my_profile", "my_documents", "my_activity"],
    })


# ── User Management API ───────────────────────────────────────────
@admin_bp.route("/api/users")
@token_required
@role_required("Admin")
def list_users(user):
    return jsonify([u.to_dict() for u in User.query.all()])


@admin_bp.route("/api/users/<int:uid>/role", methods=["PATCH"])
@token_required
@role_required("Admin")
def change_role(user, uid):
    data     = request.get_json(silent=True) or {}
    new_role = data.get("role")
    if new_role not in ("Admin", "Manager", "User"):
        return jsonify({"error": "Invalid role"}), 400
    target = User.query.get_or_404(uid)
    target.role = new_role
    db.session.commit()
    return jsonify({"message": f"Role updated to {new_role}"})


@admin_bp.route("/api/users/<int:uid>/toggle", methods=["PATCH"])
@token_required
@role_required("Admin")
def toggle_user(user, uid):
    target = User.query.get_or_404(uid)
    target.is_active = not target.is_active
    db.session.commit()
    status = "enabled" if target.is_active else "disabled"
    return jsonify({"message": f"User {status}", "is_active": target.is_active})


@admin_bp.route("/api/users/<int:uid>", methods=["DELETE"])
@token_required
@role_required("Admin")
def delete_user(user, uid):
    target = User.query.get_or_404(uid)
    for doc in target.documents:
        try:
            os.remove(doc.encrypted_path)
        except OSError:
            pass
    db.session.delete(target)
    db.session.commit()
    return jsonify({"message": "User deleted"})
