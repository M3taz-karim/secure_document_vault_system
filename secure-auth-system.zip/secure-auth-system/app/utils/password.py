import re


PASSWORD_RULES = [
    (lambda p: len(p) >= 8,                        "at least 8 characters"),
    (lambda p: bool(re.search(r'[A-Z]', p)),       "an uppercase letter"),
    (lambda p: bool(re.search(r'[a-z]', p)),       "a lowercase letter"),
    (lambda p: bool(re.search(r'\d', p)),           "a number"),
    (lambda p: bool(re.search(r'[!@#$%^&*()_+\-=\[\]{};\':"\\|,.<>\/?]', p)),
                                                    "a special character"),
]


def validate_password(password: str) -> list[str]:
    """Return list of unmet requirements (empty list = password is valid)."""
    return [msg for fn, msg in PASSWORD_RULES if not fn(password)]
