import os
import base64
import hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding, hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding


# ── RSA Key Pair (generated once at startup) ─────────────────────
_PRIVATE_KEY = rsa.generate_private_key(
    public_exponent=65537, key_size=2048, backend=default_backend()
)
_PUBLIC_KEY = _PRIVATE_KEY.public_key()


# ── AES-256-CBC ───────────────────────────────────────────────────
def aes_encrypt(plaintext: bytes, key: bytes) -> bytes:
    """Encrypt bytes with AES-256-CBC. Prepends random 16-byte IV."""
    iv = os.urandom(16)
    padder = padding.PKCS7(128).padder()
    padded = padder.update(plaintext) + padder.finalize()
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    enc = cipher.encryptor()
    return iv + enc.update(padded) + enc.finalize()


def aes_decrypt(data: bytes, key: bytes) -> bytes:
    """Decrypt AES-256-CBC blob (first 16 bytes are IV)."""
    iv, ciphertext = data[:16], data[16:]
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    dec = cipher.decryptor()
    padded = dec.update(ciphertext) + dec.finalize()
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(padded) + unpadder.finalize()


# ── SHA-256 ───────────────────────────────────────────────────────
def sha256_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


# ── RSA Digital Signature ─────────────────────────────────────────
def rsa_sign(data: bytes) -> str:
    sig = _PRIVATE_KEY.sign(data, asym_padding.PKCS1v15(), hashes.SHA256())
    return base64.b64encode(sig).decode()


def rsa_verify(data: bytes, signature_b64: str) -> bool:
    try:
        sig = base64.b64decode(signature_b64)
        _PUBLIC_KEY.verify(sig, data, asym_padding.PKCS1v15(), hashes.SHA256())
        return True
    except Exception:
        return False
