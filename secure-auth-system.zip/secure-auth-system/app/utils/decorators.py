from functools import wraps
import jwt
from flask import request, jsonify, current_app


def token_required(f):
    """Decode JWT from Authorization header and inject user payload."""
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization", "").replace("Bearer ", "").strip()
        if not token:
            token = request.args.get("token", "")
        if not token:
            return jsonify({"error": "Token missing"}), 401
        try:
            payload = jwt.decode(token, current_app.config["JWT_SECRET"], algorithms=["HS256"])
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401
        return f(payload, *args, **kwargs)
    return decorated


def role_required(*roles):
    """Restrict access to specific roles (must be used after @token_required)."""
    def wrapper(f):
        @wraps(f)
        def decorated(user, *args, **kwargs):
            if user.get("role") not in roles:
                return jsonify({"error": "Forbidden – insufficient role"}), 403
            return f(user, *args, **kwargs)
        return decorated
    return wrapper
