import io
import os
import datetime

from flask import (
    Blueprint, request, jsonify, render_template,
    send_file, current_app,
)

from app.extensions import db
from app.models.user import User
from app.models.document import Document
from app.utils import (
    aes_encrypt, aes_decrypt, sha256_hash, rsa_sign, rsa_verify,
    token_required, role_required,
)
from . import documents_bp


ALLOWED_EXTENSIONS = {"pdf", "txt", "docx", "png", "jpg", "jpeg", "csv", "xlsx"}


def _allowed(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


# ── UI Page ───────────────────────────────────────────────────────
@documents_bp.route("/ui/documents")
def documents_page():
    return render_template("documents.html")


# ── Upload ────────────────────────────────────────────────────────
@documents_bp.route("/api/documents/upload", methods=["POST"])
@token_required
def upload(user):
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400
    if not _allowed(f.filename):
        return jsonify({"error": f"File type not allowed. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"}), 400

    raw = f.read()
    max_bytes = current_app.config["MAX_FILE_SIZE_MB"] * 1024 * 1024
    if len(raw) > max_bytes:
        return jsonify({"error": f"File too large (max {current_app.config['MAX_FILE_SIZE_MB']} MB)"}), 400

    file_hash = sha256_hash(raw)
    signature = rsa_sign(raw)
    encrypted = aes_encrypt(raw, current_app.config["AES_KEY"])

    upload_folder = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_folder, exist_ok=True)
    safe_name = f"{datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{user['user_id']}_{f.filename}"
    enc_path  = os.path.join(upload_folder, safe_name + ".enc")

    with open(enc_path, "wb") as out:
        out.write(encrypted)

    doc = Document(
        filename=safe_name,
        original_name=f.filename,
        file_size=len(raw),
        file_type=f.filename.rsplit(".", 1)[1].lower(),
        sha256_hash=file_hash,
        signature=signature,
        encrypted_path=enc_path,
        user_id=user["user_id"],
    )
    db.session.add(doc)
    db.session.commit()

    return jsonify({"message": "Document uploaded, encrypted, and signed",
                    "doc_id": doc.id, "sha256": file_hash}), 201


# ── List ──────────────────────────────────────────────────────────
@documents_bp.route("/api/documents")
@token_required
def list_documents(user):
    role = user.get("role")
    if role in ("Admin", "Manager"):
        docs = Document.query.all()
    else:
        docs = Document.query.filter_by(user_id=user["user_id"]).all()
    return jsonify([d.to_dict() for d in docs])


# ── Download (decrypts on the fly) ───────────────────────────────
@documents_bp.route("/api/documents/<int:doc_id>/download")
@token_required
def download(user, doc_id):
    doc = Document.query.get_or_404(doc_id)
    if user["role"] not in ("Admin", "Manager") and doc.user_id != user["user_id"]:
        return jsonify({"error": "Access denied"}), 403

    with open(doc.encrypted_path, "rb") as ef:
        encrypted = ef.read()

    plain = aes_decrypt(encrypted, current_app.config["AES_KEY"])
    return send_file(
        io.BytesIO(plain),
        download_name=doc.original_name,
        as_attachment=True,
        mimetype="application/octet-stream",
    )


# ── Delete ────────────────────────────────────────────────────────
@documents_bp.route("/api/documents/<int:doc_id>", methods=["DELETE"])
@token_required
def delete(user, doc_id):
    doc = Document.query.get_or_404(doc_id)
    if user["role"] != "Admin" and doc.user_id != user["user_id"]:
        return jsonify({"error": "Access denied"}), 403

    try:
        os.remove(doc.encrypted_path)
    except OSError:
        pass

    db.session.delete(doc)
    db.session.commit()
    return jsonify({"message": "Document deleted"})


# ── Verify Integrity ──────────────────────────────────────────────
@documents_bp.route("/api/documents/<int:doc_id>/verify", methods=["POST"])
@token_required
def verify_integrity(user, doc_id):
    doc = Document.query.get_or_404(doc_id)
    if user["role"] not in ("Admin", "Manager") and doc.user_id != user["user_id"]:
        return jsonify({"error": "Access denied"}), 403

    with open(doc.encrypted_path, "rb") as ef:
        encrypted = ef.read()
    plain = aes_decrypt(encrypted, current_app.config["AES_KEY"])

    current_hash = sha256_hash(plain)
    hash_ok      = current_hash == doc.sha256_hash
    sig_ok       = rsa_verify(plain, doc.signature)

    if user["role"] in ("Admin", "Manager") and hash_ok and sig_ok:
        doc.verified_by = user["email"]
        doc.verified_at = datetime.datetime.utcnow()
        db.session.commit()

    return jsonify({
        "document":        doc.original_name,
        "stored_hash":     doc.sha256_hash,
        "current_hash":    current_hash,
        "hash_match":      hash_ok,
        "signature_valid": sig_ok,
        "integrity":       "INTACT" if (hash_ok and sig_ok) else "COMPROMISED",
        "verified_by":     doc.verified_by,
        "verified_at":     doc.verified_at.isoformat() if doc.verified_at else None,
    })


# ── Metadata ──────────────────────────────────────────────────────
@documents_bp.route("/api/documents/<int:doc_id>/metadata")
@token_required
def metadata(user, doc_id):
    doc = Document.query.get_or_404(doc_id)
    if user["role"] not in ("Admin", "Manager") and doc.user_id != user["user_id"]:
        return jsonify({"error": "Access denied"}), 403
    owner = User.query.get(doc.user_id)
    return jsonify(doc.to_metadata_dict(owner))
