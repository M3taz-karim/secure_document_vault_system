import datetime
from app.extensions import db


class Document(db.Model):
    __tablename__ = "document"

    id             = db.Column(db.Integer, primary_key=True)
    filename       = db.Column(db.String(255), nullable=False)
    original_name  = db.Column(db.String(255), nullable=False)
    file_size      = db.Column(db.Integer, nullable=False)
    file_type      = db.Column(db.String(50), nullable=False)
    sha256_hash    = db.Column(db.String(64), nullable=False)
    signature      = db.Column(db.Text, nullable=False)
    encrypted_path = db.Column(db.String(512), nullable=False)
    user_id        = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    uploaded_at    = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    verified_by    = db.Column(db.String(100), nullable=True)
    verified_at    = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            "id":            self.id,
            "original_name": self.original_name,
            "file_size":     self.file_size,
            "file_type":     self.file_type,
            "sha256":        self.sha256_hash,
            "signature":     self.signature[:40] + "...",
            "uploaded_at":   self.uploaded_at.isoformat(),
            "owner_id":      self.user_id,
            "verified_by":   self.verified_by,
            "verified_at":   self.verified_at.isoformat() if self.verified_at else None,
        }

    def to_metadata_dict(self, owner):
        return {
            "id":               self.id,
            "original_name":    self.original_name,
            "file_size_bytes":  self.file_size,
            "file_type":        self.file_type,
            "sha256_hash":      self.sha256_hash,
            "full_signature":   self.signature,
            "encryption":       "AES-256-CBC",
            "signing_algorithm":"RSA-2048 / SHA-256",
            "uploaded_at":      self.uploaded_at.isoformat(),
            "owner_name":       owner.name if owner else "Unknown",
            "owner_email":      owner.email if owner else "Unknown",
            "verified_by":      self.verified_by,
            "verified_at":      self.verified_at.isoformat() if self.verified_at else None,
        }
