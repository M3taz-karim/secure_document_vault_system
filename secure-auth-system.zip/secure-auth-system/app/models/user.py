import datetime
from app.extensions import db


class User(db.Model):
    __tablename__ = "user"

    id             = db.Column(db.Integer, primary_key=True)
    name           = db.Column(db.String(100), nullable=False)
    email          = db.Column(db.String(100), unique=True, nullable=False)
    password       = db.Column(db.LargeBinary(200), nullable=True)   # None for OAuth-only accounts
    role           = db.Column(db.String(20), default="User")
    secret_2fa     = db.Column(db.String(100), nullable=True)
    oauth_provider = db.Column(db.String(30), nullable=True)          # 'github' | 'google' | None
    is_active      = db.Column(db.Boolean, default=True, nullable=False)
    created_at     = db.Column(db.DateTime, default=datetime.datetime.utcnow)

    documents = db.relationship("Document", backref="owner", lazy=True, cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id":             self.id,
            "name":           self.name,
            "email":          self.email,
            "role":           self.role,
            "oauth_provider": self.oauth_provider,
            "is_active":      self.is_active,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "doc_count":      len(self.documents),
        }
