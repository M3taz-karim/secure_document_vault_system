import io
import datetime

import bcrypt
import jwt
import pyotp
import qrcode
from flask import (
    Blueprint, request, jsonify, render_template,
    redirect, url_for, send_file, current_app,
)

from app.extensions import db, oauth
from app.models.user import User
from app.utils.password import validate_password
from . import auth_bp



# ── UI Pages ─────────────────────────────────────────────────────
@auth_bp.route("/")
@auth_bp.route("/ui/login")
def login_page():
    return render_template("login.html")


@auth_bp.route("/ui/register")
def register_page():
    return render_template("register.html")


@auth_bp.route("/ui/qrcode")
def qrcode_page():
    return render_template("qrcode.html")


@auth_bp.route("/ui/verify")
def verify_page():
    return render_template("verify.html")


@auth_bp.route("/ui/oauth-success")
def oauth_success_page():
    return render_template("oauth_success.html")


# ── QR Code image ─────────────────────────────────────────────────
@auth_bp.route("/qrcode-image")
def qrcode_image():
    email = (request.args.get("email") or "").strip().lower()
    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    uri = pyotp.TOTP(user.secret_2fa).provisioning_uri(name=email, issuer_name="SecureVault")
    img = qrcode.make(uri)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


# ── API: Register ─────────────────────────────────────────────────
@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    name     = (data.get("name") or "").strip()
    email    = (data.get("email") or "").strip().lower()
    password = data.get("password", "")
    role     = data.get("role", "User")

    if len(name) < 2:
        return jsonify({"error": "Name must be at least 2 characters"}), 400
    if "@" not in email or "." not in email:
        return jsonify({"error": "Invalid email address"}), 400

    errors = validate_password(password)
    if errors:
        return jsonify({"error": "Password must contain: " + ", ".join(errors)}), 400

    if role not in ("Admin", "Manager", "User"):
        return jsonify({"error": "Invalid role"}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Email already registered"}), 400

    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    secret = pyotp.random_base32()
    user = User(name=name, email=email, password=hashed, role=role, secret_2fa=secret)
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "User registered successfully"}), 201


# ── API: Login ────────────────────────────────────────────────────
@auth_bp.route("/login", methods=["POST"])
def login():
    data     = request.get_json(silent=True) or {}
    email    = (data.get("email") or "").strip().lower()
    password = data.get("password", "")

    if not email or not password:
        return jsonify({"error": "Email and password are required"}), 400

    user = User.query.filter_by(email=email).first()
    if not user or not user.password:
        return jsonify({"error": "Invalid credentials"}), 401
    if not user.is_active:
        return jsonify({"error": "Account is disabled"}), 403
    if not bcrypt.checkpw(password.encode(), user.password):
        return jsonify({"error": "Invalid credentials"}), 401

    return jsonify({"message": "Password correct, please enter your 2FA code"}), 200


# ── API: Verify 2FA ───────────────────────────────────────────────
@auth_bp.route("/verify-2fa", methods=["POST"])
def verify_2fa():
    data  = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    code  = (data.get("code") or "").strip()

    if not email or not code:
        return jsonify({"error": "Email and code are required"}), 400

    user = User.query.filter_by(email=email).first()
    if not user:
        return jsonify({"error": "User not found"}), 404

    if not pyotp.TOTP(user.secret_2fa).verify(code, valid_window=1):
        return jsonify({"error": "Invalid or expired 2FA code"}), 401

    token = _issue_jwt(user)
    return jsonify({"token": token, "role": user.role, "name": user.name}), 200


# ── OAuth: GitHub ─────────────────────────────────────────────────
@auth_bp.route("/oauth/github")
def oauth_github():
    if not current_app.config.get("GITHUB_CLIENT_ID"):
        return render_template("oauth_not_configured.html", provider="GitHub",
                               guide_url="https://github.com/settings/applications/new",
                               callback_url=url_for("auth.oauth_github_callback", _external=True))
    redirect_uri = url_for("auth.oauth_github_callback", _external=True)
    return oauth.github.authorize_redirect(redirect_uri)


@auth_bp.route("/oauth/github/callback")
def oauth_github_callback():
    try:
        token       = oauth.github.authorize_access_token()
        profile     = oauth.github.get("user", token=token).json()
        emails_resp = oauth.github.get("user/emails", token=token).json()
        email = next((e["email"] for e in emails_resp if e.get("primary")), None) \
                or profile.get("email")
        if not email:
            return redirect("/ui/login?error=no_email")
        name = profile.get("name") or profile.get("login") or "GitHub User"
        return _oauth_finalize(email, name, "github")
    except Exception:
        return redirect("/ui/login?error=oauth_failed")


# ── OAuth: Google ─────────────────────────────────────────────────
@auth_bp.route("/oauth/google")
def oauth_google():
    if not current_app.config.get("GOOGLE_CLIENT_ID"):
        return render_template("oauth_not_configured.html", provider="Google",
                               guide_url="https://console.cloud.google.com/apis/credentials",
                               callback_url=url_for("auth.oauth_google_callback", _external=True))
    redirect_uri = url_for("auth.oauth_google_callback", _external=True)
    return oauth.google.authorize_redirect(redirect_uri)


@auth_bp.route("/oauth/google/callback")
def oauth_google_callback():
    try:
        token   = oauth.google.authorize_access_token()
        profile = token.get("userinfo") or oauth.google.userinfo(token=token)
        email   = profile.get("email")
        name    = profile.get("name") or "Google User"
        if not email:
            return redirect("/ui/login?error=no_email")
        return _oauth_finalize(email, name, "google")
    except Exception:
        return redirect("/ui/login?error=oauth_failed")


# ── Helpers ───────────────────────────────────────────────────────
def _issue_jwt(user: User) -> str:
    return jwt.encode(
        {
            "user_id": user.id,
            "email":   user.email,
            "name":    user.name,
            "role":    user.role,
            "exp":     datetime.datetime.utcnow() + datetime.timedelta(hours=2),
        },
        current_app.config["JWT_SECRET"],
        algorithm="HS256",
    )


def _oauth_finalize(email: str, name: str, provider: str):
    """Find or create user from OAuth profile, then issue JWT and redirect."""
    user = User.query.filter_by(email=email).first()
    if not user:
        user = User(
            name=name, email=email, role="User",
            secret_2fa=pyotp.random_base32(),
            oauth_provider=provider,
        )
        db.session.add(user)
        db.session.commit()

    token = _issue_jwt(user)
    return redirect(
        f"/ui/oauth-success?token={token}&role={user.role}&name={name}"
    )
