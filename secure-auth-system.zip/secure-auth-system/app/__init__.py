import os
from flask import Flask
from app.config import Config
from app.extensions import db, oauth


def create_app(config_class=Config) -> Flask:
    """Application factory."""
    # Template folder points to the templates/ directory at the project root
    template_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "templates")

    app = Flask(__name__, template_folder=template_dir)
    app.config.from_object(config_class)

    # Ensure upload directory exists
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    # ── Extensions ────────────────────────────────────────────────
    db.init_app(app)
    oauth.init_app(app)

    # ── OAuth Providers (only register if credentials are set) ────
    if app.config.get("GITHUB_CLIENT_ID"):
        oauth.register(
            name="github",
            client_id=app.config["GITHUB_CLIENT_ID"],
            client_secret=app.config["GITHUB_CLIENT_SECRET"],
            access_token_url="https://github.com/login/oauth/access_token",
            authorize_url="https://github.com/login/oauth/authorize",
            api_base_url="https://api.github.com/",
            client_kwargs={"scope": "user:email"},
        )

    if app.config.get("GOOGLE_CLIENT_ID"):
        oauth.register(
            name="google",
            client_id=app.config["GOOGLE_CLIENT_ID"],
            client_secret=app.config["GOOGLE_CLIENT_SECRET"],
            server_metadata_url="https://accounts.google.com/.well-known/openid-configuration",
            client_kwargs={"scope": "openid email profile"},
        )

    # ── Blueprints ────────────────────────────────────────────────
    from app.auth import auth_bp
    from app.documents import documents_bp
    from app.admin import admin_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(documents_bp)
    app.register_blueprint(admin_bp)

    # ── Database ──────────────────────────────────────────────────
    with app.app_context():
        from app.models import User, Document  # noqa: F401 – ensure models are imported
        db.create_all()

    return app
