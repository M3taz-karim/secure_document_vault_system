import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # Flask
    SECRET_KEY = os.environ.get("FLASK_SECRET", "change_me_in_production")

    # Database
    SQLALCHEMY_DATABASE_URI = "sqlite:///database.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # JWT
    JWT_SECRET = os.environ.get("JWT_SECRET", "change_me_jwt_secret_32chars_min!")

    # AES-256 encryption key (must be exactly 32 bytes)
    AES_KEY = os.environ.get("AES_KEY", "ThisIsA32ByteKeyForAES256Encrypt!").encode()[:32]

    # File uploads
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), "encrypted_docs")
    ALLOWED_EXTENSIONS = {"pdf", "txt", "docx", "png", "jpg", "jpeg", "csv", "xlsx"}
    MAX_FILE_SIZE_MB = 10

    # OAuth – GitHub
    GITHUB_CLIENT_ID     = os.environ.get("GITHUB_CLIENT_ID", "")
    GITHUB_CLIENT_SECRET = os.environ.get("GITHUB_CLIENT_SECRET", "")

    # OAuth – Google
    GOOGLE_CLIENT_ID     = os.environ.get("GOOGLE_CLIENT_ID", "")
    GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
